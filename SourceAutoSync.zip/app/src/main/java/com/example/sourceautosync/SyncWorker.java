package com.example.sourceautosync;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONArray;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.URI;
import java.net.URL;
import java.security.MessageDigest;

/**
 * Sync worker: fetch book source JSON from GitHub, then write into
 * Legado reader app via its ContentProvider (batched inserts).
 */
public class SyncWorker extends Worker {

    private static final String AUTHORITY = "com.legado.app.release.readerProvider";
    private static final String[] URLS = {
            // 1-3: 国内专用 GitHub CDN 中转（解决 vivo/国内运营商屏蔽 GitHub）
            "https://ghproxy.net/https://raw.githubusercontent.com/NErvous-bot/Nervous/main/legado.json",
            "https://ghfast.top/https://raw.githubusercontent.com/NErvous-bot/Nervous/main/legado.json",
            "https://gh-proxy.com/https://raw.githubusercontent.com/NErvous-bot/Nervous/main/legado.json",
            // 4: jsDelivr CDN（已有国内节点）
            "https://cdn.jsdelivr.net/gh/NErvous-bot/Nervous@main/legado.json",
            // 5: 原始 GitHub（兜底，某些运营商可能反而通）
            "https://raw.githubusercontent.com/NErvous-bot/Nervous/main/legado.json"
    };
    private static final int BATCH = 80;

    public SyncWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context ctx = getApplicationContext();
        android.content.SharedPreferences sp = ctx.getSharedPreferences("sync", Context.MODE_PRIVATE);

        String json = null;
        for (String u : URLS) {
            json = fetch(u);
            if (json != null) break;
        }
        if (json == null) {
            save("失败：所有 5 条下载线路都无法访问，请检查网络");
            return Result.retry();
        }

        File cache = new File(getApplicationContext().getFilesDir(), "last.json");
        if (cache.exists() && md5(cache).equals(md5(json))) {
            save("检查完成：无变化，已跳过写入");
            return Result.success();
        }

        try {
            JSONArray all = new JSONArray(json);
            int total = all.length();
            Uri uri = Uri.parse("content://" + AUTHORITY + "/bookSources/insert");
            for (int i = 0; i < total; i += BATCH) {
                JSONArray part = new JSONArray();
                for (int j = i; j < Math.min(i + BATCH, total); j++) {
                    part.put(all.get(j));
                }
                ContentValues v = new ContentValues();
                v.put("json", part.toString());
                getApplicationContext().getContentResolver().insert(uri, v);
            }
            OutputStream os = new FileOutputStream(cache);
            os.write(json.getBytes("UTF-8"));
            os.close();
            save("成功：已写入 " + total + " 个书源");
            sp.edit().putLong("lastOk", System.currentTimeMillis()).apply();
            return Result.success();
        } catch (Exception e) {
            save("失败：" + e.getMessage());
            return Result.failure();
        }
    }

    /** Download url content, return null on failure. */
    private String fetch(String urlStr) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            // 显式读系统代理（Android 14 部分 ROM 默认会读，显式调用更稳）
            // 优先级：HTTP_PROXY 环境变量 > 系统 Wifi 代理/PAC > 直连
            Proxy proxy = pickProxy(url);
            conn = (HttpURLConnection) (proxy == Proxy.NO_PROXY
                    ? url.openConnection()
                    : url.openConnection(proxy));
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(20000);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/142.0 Mobile Safari/537.36");
            InputStream in = conn.getInputStream();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            in.close();
            return bos.toString("UTF-8");
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    /** 智能选代理：环境变量 HTTP_PROXY/HTTPS_PROXY > 系统 ProxySelector > 直连 */
    private Proxy pickProxy(URL url) {
        // 1) HTTP_PROXY / HTTPS_PROXY 环境变量（部分代理工具会注入）
        try {
            String envKey = "HTTPS_PROXY";
            String env = System.getenv(envKey);
            if (env == null || env.isEmpty()) {
                envKey = "HTTP_PROXY";
                env = System.getenv(envKey);
            }
            if (env != null && !env.isEmpty()) {
                java.net.URI u = java.net.URI.create(env.contains("://") ? env : "http://" + env);
                String h = u.getHost();
                int p = u.getPort() == -1 ? 8888 : u.getPort();
                if (h != null) return new Proxy(Proxy.Type.HTTP, new java.net.InetSocketAddress(h, p));
            }
        } catch (Exception ignored) {}
        // 2) 系统代理（Wifi 设置的代理 / PAC 脚本）
        try {
            URI uri = url.toURI();
            java.util.List<Proxy> proxies = ProxySelector.getDefault().select(uri);
            if (proxies != null && !proxies.isEmpty()) {
                Proxy p = proxies.get(0);
                if (p != null && p.address() != null) return p;
            }
        } catch (Exception ignored) {}
        return Proxy.NO_PROXY;
    }

    private String md5(String text) {
        try {
            byte[] d = MessageDigest.getInstance("MD5").digest(text.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private String md5(File file) {
        try {
            FileInputStream fis = new FileInputStream(file);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = fis.read(buf)) > 0) bos.write(buf, 0, n);
            fis.close();
            return md5(new String(bos.toByteArray(), "UTF-8"));
        } catch (Exception e) {
            return "";
        }
    }

    private void save(String msg) {
        getApplicationContext()
                .getSharedPreferences("sync", Context.MODE_PRIVATE)
                .edit()
                .putString("last", new java.text.SimpleDateFormat(
                        "MM-dd HH:mm", java.util.Locale.CHINA).format(new java.util.Date())
                        + " " + msg)
                .apply();
    }
}
