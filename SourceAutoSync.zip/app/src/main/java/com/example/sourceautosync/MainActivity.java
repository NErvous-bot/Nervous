package com.example.sourceautosync;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {

    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);

        // manual sync button (ignores schedule, syncs immediately)
        findViewById(R.id.syncNow).setOnClickListener(v -> {
            WorkManager.getInstance(this).enqueueUniqueWork("manual",
                    ExistingWorkPolicy.REPLACE,
                    new OneTimeWorkRequest.Builder(SyncWorker.class)
                            .addTag("manual").build());
            refresh();
        });

        // daily check at 5am: only writes into Legado when GitHub content changed
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("daily",
                ExistingPeriodicWorkPolicy.KEEP,
                new PeriodicWorkRequest.Builder(SyncWorker.class, 24, TimeUnit.HOURS)
                        .setInitialDelay(delayUntilNext5am(), TimeUnit.MILLISECONDS).build());

        refresh();
    }

    /** milliseconds until next 5:00 am */
    private static long delayUntilNext5am() {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.set(java.util.Calendar.HOUR_OF_DAY, 5);
        cal.set(java.util.Calendar.MINUTE, 0);
        cal.set(java.util.Calendar.SECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
            cal.add(java.util.Calendar.DAY_OF_YEAR, 1);
        }
        return cal.getTimeInMillis() - System.currentTimeMillis();
    }

    private void refresh() {
        String last = getSharedPreferences("sync", MODE_PRIVATE)
                .getString("last", "从未同步（安装后打开一次即注册每日任务）");
        status.setText(
                "书源自动同步 v3.3\n\n" +
                "订阅源：NErvous-bot/x2yefuobr-15whlj\n" +
                "写入目标：阅读App（com.legado.app.release）\n" +
                "更新频率：每天凌晨自动检查，GitHub 有更新才写入\n" +
                "同步内容：书源 + 全局净化规则\n" +
                "镜像线路：云端自动获取，线路失效自动切换\n\n" +
                "上次同步结果：\n" + last + "\n\n" +
                "提示：请在系统设置中允许本App「后台运行/自启动」，否则定时任务可能被省电机制拦截。");
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }
}
