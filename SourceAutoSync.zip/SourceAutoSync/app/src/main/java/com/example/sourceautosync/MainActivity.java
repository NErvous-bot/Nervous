package com.example.sourceautosync;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {

    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);

        // 手动同步按钮（不受周一窗口限制，点了就同步）
        findViewById(R.id.syncNow).setOnClickListener(v -> {
            WorkManager.getInstance(this).enqueueUniqueWork("manual",
                    ExistingWorkPolicy.REPLACE,
                    new OneTimeWorkRequest.Builder(SyncWorker.class)
                            .addTag("manual").build());
            refresh();
        });

        // 每天凌晨5点醒一次检查：GitHub 有更新才写入，无更新几秒结束
        // （首次对齐下一个凌晨5点；KEEP 策略保证重复打开App不会重置计划）
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("daily",
                ExistingPeriodicWorkPolicy.KEEP,
                new PeriodicWorkRequest.Builder(SyncWorker.class, 24, TimeUnit.HOURS)
                        .setInitialDelay(delayUntilNext5am(), TimeUnit.MILLISECONDS).build());

        refresh();
    }

    /** 距下一个凌晨5点的毫秒数 */
    private static long delayUntilNext5am() {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.set(java.util.Calendar.HOUR_OF_DAY, 5);
        cal.set(java.util.Calendar.MINUTE, 0);
        cal.set(java.util.Calendar.SECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
            cal.add(java.util.Calendar.DAY_OF_YEAR, 1);
        }
        return cal.getTimeInMillis() - System.currentTimeMillis();
    }

    private void refresh() {
        String last = getSharedPreferences("sync", MODE_PRIVATE)
                .getString("last", "从未同步（安装后打开一次即注册每日任务）");
        status.setText(
                "书源自动同步 v1.0\n\n" +
                "订阅源：NErvous-bot/Nervous\n" +
                "写入目标：阅读App（com.legado.app.release）\n" +
                "更新频率：每天凌晨自动检查，GitHub 有更新才写入\n\n" +
                "上次同步结果：\n" + last + "\n\n" +
                "提示：请在系统设置中允许本App「后台运行/自启动」，否则定时任务可能被省电机制拦截。");
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }
}
