package com.example.sourceautosync;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONArray;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

/**
 * 书源同步任务：拉取 GitHub 订阅 JSON → 分批写入阅读App的 ContentProvider。
 * 设计要点：
 * 1. 双线路回退：jsDelivr 主线路（国内可达），raw 备线路
 * 2. 内容哈希对比，无变化不写库（省电）
 * 3. 分批 insert（每批 80 个源），规避 Binder 事务 1MB 上限
 */
public class SyncWorker extends Worker {

    private static final String AUTHORITY = "com.legado.app.release.readerProvider";
    private static final String[] URLS = {
            "https://cdn.jsdelivr.net/gh/NErvous-bot/Nervous@main/legado.json",
            "https://raw.githubusercontent.com/NErvous-bot/Nervous/main/legado.json"
    };
    private static final int BATCH = 80;

    public SyncWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context ctx = getApplicationContext();
        android.content.SharedPreferences sp = ctx.getSharedPreferences("sync", Context.MODE_PRIVATE);

        String json = null;
        for (String u : URLS) {
            json = fetch(u);
            if (json != null) break;
        }
        if (json == null) {
            save("失败：两条线路都拉不到订阅文件（检查网络）");
            return Result.retry();
        }

        // 无变化则跳过写入（GitHub 每3天更新一次，没更新的日子几秒钟就结束）
        File cache = new File(getApplicationContext().getFilesDir(), "last.json");
        if (cache.exists() && md5(cache).equals(md5(json))) {
            save("检查完毕：GitHub 无更新");
            return Result.success();
        }

        try {
            JSONArray all = new JSONArray(json);
            int total = all.length();
            Uri uri = Uri.parse("content://" + AUTHORITY + "/bookSources/insert");
            for (int i = 0; i < total; i += BATCH) {
                JSONArray part = new JSONArray();
                for (int j = i; j < Math.min(i + BATCH, total); j++) {
                    part.put(all.get(j));
                }
                ContentValues v = new ContentValues();
                v.putString("json", part.toString());
                getApplicationContext().getContentResolver().insert(uri, v);
            }
            OutputStream os = new FileOutputStream(cache);
            os.write(json.getBytes("UTF-8"));
            os.close();
            save("成功：已写入 " + total + " 个书源到阅读App");
            sp.edit().putLong("lastOk", System.currentTimeMillis()).apply();
            return Result.success();
        } catch (Exception e) {
            save("失败：" + e.getClass().getSimpleName() + ": " + e.getMessage());
            return Result.failure();
        }
    }

    /** 下载 URL 内容，失败返回 null */
    private String fetch(String urlStr) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(20000);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/142.0 Mobile Safari/537.36");
            InputStream in = conn.getInputStream();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            in.close();
            return bos.toString("UTF-8");
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private String md5(String text) {
        try {
            byte[] d = MessageDigest.getInstance("MD5").digest(text.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private String md5(File file) {
        try {
            FileInputStream fis = new FileInputStream(file);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = fis.read(buf)) > 0) bos.write(buf, 0, n);
            fis.close();
            return md5(new String(bos.toByteArray(), "UTF-8"));
        } catch (Exception e) {
            return "";
        }
    }

    private void save(String msg) {
        getApplicationContext()
                .getSharedPreferences("sync", Context.MODE_PRIVATE)
                .edit()
                .putString("last", new java.text.SimpleDateFormat(
                        "MM-dd HH:mm", java.util.Locale.CHINA).format(new java.util.Date())
                        + " — " + msg)
                .apply();
    }
}
