package com.example.sourceautosync;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONArray;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

/**
 * Sync worker: fetch book source JSON from GitHub, then write into
 * Legado reader app via its ContentProvider (batched inserts).
 */
public class SyncWorker extends Worker {

    private static final String AUTHORITY = "com.legado.app.release.readerProvider";
    private static final String[] URLS = {
            "https://cdn.jsdelivr.net/gh/NErvous-bot/Nervous@main/legado.json",
            "https://raw.githubusercontent.com/NErvous-bot/Nervous/main/legado.json"
    };
    private static final int BATCH = 80;

    public SyncWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context ctx = getApplicationContext();
        android.content.SharedPreferences sp = ctx.getSharedPreferences("sync", Context.MODE_PRIVATE);

        String json = null;
        for (String u : URLS) {
            json = fetch(u);
            if (json != null) break;
        }
        if (json == null) {
            save("failed: both download lines unreachable");
            return Result.retry();
        }

        File cache = new File(getApplicationContext().getFilesDir(), "last.json");
        if (cache.exists() && md5(cache).equals(md5(json))) {
            save("checked: GitHub has no update");
            return Result.success();
        }

        try {
            JSONArray all = new JSONArray(json);
            int total = all.length();
            Uri uri = Uri.parse("content://" + AUTHORITY + "/bookSources/insert");
            for (int i = 0; i < total; i += BATCH) {
                JSONArray part = new JSONArray();
                for (int j = i; j < Math.min(i + BATCH, total); j++) {
                    part.put(all.get(j));
                }
                ContentValues v = new ContentValues();
                try {
                    ContentValues.class.getMethod("putString", String.class, String.class)
                            .invoke(v, "json", part.toString());
                } catch (ReflectiveOperationException e) {
                    throw new IllegalStateException("ContentValues.putString missing: " + e, e);
                }
                getApplicationContext().getContentResolver().insert(uri, v);
            }
            OutputStream os = new FileOutputStream(cache);
            os.write(json.getBytes("UTF-8"));
            os.close();
            save("success: wrote " + total + " book sources into Legado");
            sp.edit().putLong("lastOk", System.currentTimeMillis()).apply();
            return Result.success();
        } catch (Exception e) {
            save("failed: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            return Result.failure();
        }
    }

    /** Download url content, return null on failure. */
    private String fetch(String urlStr) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(20000);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/142.0 Mobile Safari/537.36");
            InputStream in = conn.getInputStream();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            in.close();
            return bos.toString("UTF-8");
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private String md5(String text) {
        try {
            byte[] d = MessageDigest.getInstance("MD5").digest(text.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private String md5(File file) {
        try {
            FileInputStream fis = new FileInputStream(file);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = fis.read(buf)) > 0) bos.write(buf, 0, n);
            fis.close();
            return md5(new String(bos.toByteArray(), "UTF-8"));
        } catch (Exception e) {
            return "";
        }
    }

    private void save(String msg) {
        getApplicationContext()
                .getSharedPreferences("sync", Context.MODE_PRIVATE)
                .edit()
                .putString("last", new java.text.SimpleDateFormat(
                        "MM-dd HH:mm", java.util.Locale.CHINA).format(new java.util.Date())
                        + " " + msg)
                .apply();
    }
}
