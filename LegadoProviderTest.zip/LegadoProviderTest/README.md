# LegadoProviderTest

这是给《阅读》3.26082823 做的第一阶段只读测试工程。

## 测试内容
- 使用官方 Content Provider 方式查询书源
- 目标 authority：`io.legado.app.release.readerProvider`
- 只查询，不新增、不删除、不修改书源
- 如果当前没有导入书源，成功时应显示“当前书源数量：0”

## 编译
用 Android Studio 打开本目录，等待 Gradle Sync 完成，然后：
Build -> Build APK(s)

如果你的《阅读》实际包名不是 `io.legado.app.release`，这个测试版会提示失败，需要根据实际包名调整 authority。

官方 API 文档：
https://github.com/LegadoTeam/legado/blob/master/api.md
