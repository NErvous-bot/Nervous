package com.example.legadoprovidertest;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.CursorLoader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;
    private String lastResult = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        Button button = findViewById(R.id.testButton);
        button.setOnClickListener(v -> testProvider());

        testProvider();
    }

    private void testProvider() {
        status.setText("正在扫描手机上所有带「阅读接口」的应用...");
        new Thread(() -> {
            StringBuilder sb = new StringBuilder();
            int found = 0;
            try {
                android.content.pm.PackageManager pm = getPackageManager();
                // 需要 QUERY_ALL_PACKAGES 权限（manifest 已声明）
                java.util.List<android.content.pm.PackageInfo> pkgs =
                        pm.getInstalledPackages(android.content.pm.PackageManager.GET_PROVIDERS);
                for (android.content.pm.PackageInfo p : pkgs) {
                    if (p.providers == null) continue;
                    for (android.content.pm.ProviderInfo pi : p.providers) {
                        if (pi.authority == null || !pi.authority.endsWith(".readerProvider")) continue;
                        found++;
                        sb.append("发现应用: ").append(p.packageName)
                          .append("（版本 ").append(p.versionName).append("）\n");
                        Uri uri = Uri.parse("content://" + pi.authority + "/bookSources/query");
                        String res;
                        try {
                            ContentResolver resolver = getContentResolver();
                            Cursor cursor = resolver.query(uri, null, null, null, null);
                            if (cursor == null) {
                                res = "❌ 查询返回 null（此版本接口实现不同）";
                            } else {
                                int count = cursor.getCount();
                                cursor.close();
                                res = "✅ 连接成功！书源数量: " + count;
                            }
                        } catch (SecurityException e) {
                            res = "⚠️ 权限被拒绝: " + e.getMessage();
                        } catch (Exception e) {
                            res = "❌ " + e.getClass().getSimpleName() + ": " + e.getMessage();
                        }
                        sb.append("接口: ").append(pi.authority).append("\n")
                          .append("结果: ").append(res).append("\n\n");
                        lastResult = pi.authority + " → " + res;
                    }
                }
            } catch (Exception e) {
                sb.append("扫描出错: ").append(e).append("\n\n");
            }
            if (found == 0) {
                sb.append("未发现任何带「阅读接口(readerProvider)」的应用。\n\n")
                  .append("说明你安装的阅读版本不含此接口（版本过旧或为特殊分支）。");
            }
            final String out = sb.toString();
            runOnUiThread(() -> status.setText(out));
        }).start();
    }
}
