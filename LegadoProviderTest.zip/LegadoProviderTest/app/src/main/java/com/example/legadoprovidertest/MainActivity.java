package com.example.legadoprovidertest;

import android.app.Activity;
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String AUTHORITY = "io.legado.app.release.readerProvider";
    private static final Uri BOOK_SOURCES =
            Uri.parse("content://" + AUTHORITY + "/bookSources/query");

    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        Button button = findViewById(R.id.testButton);
        button.setOnClickListener(v -> testProvider());

        testProvider();
    }

    private void testProvider() {
        status.setText("正在检测...\n\n目标：" + AUTHORITY);
        new Thread(() -> {
            String result;
            Cursor cursor = null;
            try {
                ContentResolver resolver = getContentResolver();
                cursor = resolver.query(BOOK_SOURCES, null, null, null, null);

                if (cursor == null) {
                    result = "❌ 查询返回 null\n\n"
                            + "可能原因：Provider 不存在、权限不匹配，"
                            + "或当前安装包不是 io.legado.app.release。";
                } else {
                    int count = 0;
                    while (cursor.moveToNext()) {
                        count++;
                    }
                    result = "✅ Content Provider 连接成功\n\n"
                            + "当前书源数量：" + count + "\n\n"
                            + "本次只读取，没有修改任何数据。";
                }
            } catch (SecurityException e) {
                result = "⚠️ Provider 存在，但权限被拒绝\n\n"
                        + e.getMessage();
            } catch (Exception e) {
                result = "❌ 检测失败\n\n"
                        + e.getClass().getSimpleName() + ": " + e.getMessage();
            } finally {
                if (cursor != null) cursor.close();
            }

            final String finalResult = result;
            runOnUiThread(() -> status.setText(finalResult));
        }).start();
    }
}
